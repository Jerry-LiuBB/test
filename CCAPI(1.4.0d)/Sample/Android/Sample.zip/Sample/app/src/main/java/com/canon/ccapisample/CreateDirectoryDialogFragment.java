package com.canon.ccapisample;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;
import static com.canon.ccapisample.Constants.CCAPI.Field.CREATEDIRECTORY;

public class CreateDirectoryDialogFragment extends DialogFragment {

    private static final String TAG = CreateDirectoryDialogFragment.class.getSimpleName();

    private WebAPI mWebAPI;
    private TextView mDirectoryNameTextView;

    private final Map<String, EditText> mCreateDirectoryStringViewMap = new HashMap<>();

    public CreateDirectoryDialogFragment() {
        // Required empty public constructor
    }

    public static CreateDirectoryDialogFragment newInstance(Fragment target) {
        CreateDirectoryDialogFragment fragment = new CreateDirectoryDialogFragment();
        fragment.setTargetFragment(target, 0);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle arguments) {

        mWebAPI = WebAPI.getInstance();

        LinearLayout parentLayout = new LinearLayout(getActivity());
        parentLayout.setOrientation(LinearLayout.VERTICAL);

        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());

        dialog.setTitle("DirectoryName");

        Context context = getActivity();

        LinearLayout subLayout = new LinearLayout(context);
        subLayout.setOrientation(LinearLayout.HORIZONTAL);

        EditText editText = new EditText(getActivity());
        editText.setHint("default");
        subLayout.addView(editText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));

        mCreateDirectoryStringViewMap.put(CREATEDIRECTORY, editText);

        parentLayout.addView(subLayout, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        dialog.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                CreateDirectory();
            }
        });

        dialog.setView(parentLayout);

        return dialog.create();
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
    }

    private void CreateDirectory(){

        String data = new String();
        data += mCreateDirectoryStringViewMap.get(CREATEDIRECTORY).getText().toString();
        Bundle args = new Bundle();

        args.putString(Constants.RequestCode.POST_FUNCTIONS_CREATEDIRECTORY.name(), data);

        mWebAPI.enqueueRequest(new WebAPIQueueDataSet(Constants.RequestCode.POST_FUNCTIONS_CREATEDIRECTORY, args, (WebAPIResultListener) getTargetFragment()));
    }
}
